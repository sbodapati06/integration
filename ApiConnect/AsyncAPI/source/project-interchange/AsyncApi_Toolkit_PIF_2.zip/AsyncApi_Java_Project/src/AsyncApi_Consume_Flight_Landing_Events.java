import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.CommonClientConfigs;

import java.io.IOException;
import java.time.Duration;
import java.util.Collections;
import java.util.Properties;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;

public class AsyncApi_Consume_Flight_Landing_Events {
	public static final void main(String args[]) {
		Properties props = new Properties();

//		props.put("bootstrap.servers",
//				"eventstreams-kafka-bootstrap-cp4i-es.ocp-dev-290268003089a11bfac4ffe6a9d666b7-0000.us-east.containers.appdomain.cloud:443");
	    props.put("bootstrap.servers", "apis-minim-a2901f0b-event-gw-client-cp4i-apic.ocp-dev-290268003089a11bfac4ffe6a9d666b7-0000.us-east.containers.appdomain.cloud:443");

		props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		props.put("value.deserializer", "org.apache.kafka.common.serialization.ByteArrayDeserializer");

		props.put("group.id", "2");
	    props.put("client.id", "88f19049-b245-43d2-92b1-72afc6a50bc8");

		props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_SSL");

		props.put(SaslConfigs.SASL_MECHANISM, "PLAIN");
	    props.put(SaslConfigs.SASL_JAAS_CONFIG,
	    	      "org.apache.kafka.common.security.plain.PlainLoginModule required " +
	    	      "username=\"b0553d05012573a7d5afeaf4a9d119fd\" " +
	    	      "password=\"ca03b7192b9429c9463a2fcff989d731\";");

	    // The Kafka cluster may have encryption enabled. Contact the API owner for the appropriate TrustStore configuration.
	    props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "/Users/sbodapati/xibm_ts/sb_demos/eventstreams/eventgateway/bootstrap.jks");
	    props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, "passw0rd");
	    props.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "JKS");
	    props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "");
	    
//		props.put("ssl.truststore.location",
	    
	//			"/Users/sbodapati/xibm_ts/sb_demos/eventstreams/eventgateway/bootstrap.jks");
		//props.put("ssl.truststore.type", "JKS");
		//props.put("ssl.truststore.password", "passw0rd");
		//props.put("ssl.endpoint.identification.algorithm", "");

		KafkaConsumer<String, byte[]> consumer = new KafkaConsumer<String, byte[]>(props);
		consumer.subscribe(Collections.singletonList("STUDENT00.FLIGHT.LANDINGS"));
		//try {
			while (true) {
				ConsumerRecords<String, byte[]> records = consumer.poll(Duration.ofSeconds(10));
				for (ConsumerRecord<String, byte[]> record : records) {
					byte[] value = record.value();
					String key = record.key();
					ObjectMapper om = new ObjectMapper();
					JsonNode jsonNode;
					try {
						jsonNode = om.readTree(value);
					
					// Do something with your JSON data
					String flightNumber = jsonNode.get("flight").asText();
					String terminal = jsonNode.get("flight").asText();
					String numPassengers = jsonNode.get("flight").asText();

					System.out.println("DEBUG: A FLIGHT HAS LANDED!");
					System.out.println("         flight number: " + flightNumber);
					System.out.println("              terminal: " + terminal);
					System.out.println("  number of passengers: " + numPassengers);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			// consumer.close();
//			// System.exit(1);
//		}
	}
}






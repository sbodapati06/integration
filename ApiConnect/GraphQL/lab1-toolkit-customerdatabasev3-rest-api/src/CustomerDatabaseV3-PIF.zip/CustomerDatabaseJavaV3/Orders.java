import java.util.concurrent.atomic.AtomicInteger;

public class Orders {

	private static AtomicInteger currentID = new AtomicInteger(1);

	private String carrier;
	private String createdAt;
	private double shippingCost;
	
	public Orders( String carrier, String createdAt, double shippingCost) {
		this.carrier = carrier;
		this.createdAt = createdAt;
		this.shippingCost = shippingCost;		
	}

	public String getCarrier() {
		return carrier;
	}

	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public String setCreatedAt() {
		return createdAt;
	}
/*	
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	public int getCustomerId() {
		return customerId;
	}
*/
	public double getShippingCost() {
		return shippingCost;
	}

	public void setShippingCost(float shippingCost) {
		this.shippingCost = shippingCost;
	}

	
}

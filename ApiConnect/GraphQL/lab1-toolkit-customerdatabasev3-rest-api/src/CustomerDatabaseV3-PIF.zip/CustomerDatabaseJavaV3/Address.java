import java.util.concurrent.atomic.AtomicInteger;

public class Address {

	private static AtomicInteger currentID = new AtomicInteger(1);

	private int id;
	private String street;
	private String city;
	private String state;
	private String country;
	private String postalCode;
	
	public Address(String street, String city, String state, String country,String postalCode) {
		id = currentID.getAndIncrement();
		this.street = street;
		this.city = city;
		this.state = state;
		this.country = country;
		this.postalCode = postalCode;		
	}

	public int getID() {
		return id;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setpostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

}
